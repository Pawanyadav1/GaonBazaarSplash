package com.devrik.gaonbazaarsplash.others;

public class API {
    public static String BASEURL="https://developerdeepika.com/gaon_bazaar/appservice/process.php?action=";
    public static String Signup=BASEURL+"signup";
    public static String login=BASEURL+"login";
    public static String otp_verfication=BASEURL+"otp_verfication";
    public static String forget_password=BASEURL+"forget_password";
    public static String update_profile=BASEURL+"update_profile";
    public static String show_state=BASEURL+"show_state";
    public static String show_district=BASEURL+"show_district";
    public static String show_block=BASEURL+"show_block";
    public static String show_village=BASEURL+"show_village";
    public static String show_category=BASEURL+"show_category";
    public static String show_product=BASEURL+"show_product";
    public static String add_product=BASEURL+"add_product";
    public static String show_my_product=BASEURL+"show_my_product";
    public static String show_brand = BASEURL+"show_brand";
    public static String add_bank_account=BASEURL+"add_bank_account";
    public static String contact_us= BASEURL+"contact_us";
    
}
