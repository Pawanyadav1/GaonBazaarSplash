package com.devrik.gaonbazaarsplash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.gaonbazaarsplash.others.API;
import com.devrik.gaonbazaarsplash.others.APPCONSTANT;
import com.devrik.gaonbazaarsplash.others.SharedHelper;

import org.json.JSONException;
import org.json.JSONObject;

public class Otp_Sign_Up_Activity extends AppCompatActivity {
    EditText edittextotp;
    Button button;
    String MOBILE="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp__sign__up);

        MOBILE = SharedHelper.getKey(Otp_Sign_Up_Activity.this,APPCONSTANT.MOBILE);
        Log.e("dsgfgs",MOBILE);

        edittextotp = findViewById(R.id.edittextotp);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validateDetail();

            }


        });
    }


    private void validateDetail() {
        if (edittextotp.getText().toString().equals("")) {
            edittextotp.setError("please enter OTP ");
            edittextotp.requestFocus();

        } else {

            otpsignUpGoan();

        }

    }

    private void otpsignUpGoan(){
        Log.e("ffdfdfdfdf", MOBILE);

        AndroidNetworking.post(API.otp_verfication)
                .addBodyParameter("otp",edittextotp.getText().toString().trim())
                .addBodyParameter("mobile",MOBILE)
                .setTag("otp")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("svhgs", response.toString());
                        try {
                            if (response.getString("result").equals("Login Successful")) {

                                SharedHelper.putKey(Otp_Sign_Up_Activity.this, APPCONSTANT.USERID);
                                startActivity(new Intent(Otp_Sign_Up_Activity.this,SignInGaonActivity.class));
                            }else {
                                Toast.makeText(Otp_Sign_Up_Activity.this, ""+response.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("unsuccess", e.getMessage());
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("xSscSsdss", anError.getMessage());


                    }
                });

    }



}
