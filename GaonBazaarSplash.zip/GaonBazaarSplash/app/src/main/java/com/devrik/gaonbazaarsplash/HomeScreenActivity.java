package com.devrik.gaonbazaarsplash;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.devrik.gaonbazaarsplash.others.APPCONSTANT;
import com.devrik.gaonbazaarsplash.others.SharedHelper;
import com.google.android.material.card.MaterialCardView;


public class HomeScreenActivity extends AppCompatActivity {
    TextView txt1;
    ImageView buy1,menu,mail_contact,logout;
    MaterialCardView buyitems,sell_item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        sell_item = findViewById(R.id.sell_item);
        buyitems = findViewById(R.id.buyitems);
        txt1 = findViewById(R.id.txt1);
        mail_contact = findViewById(R.id.mail_contact);
        buy1 = findViewById(R.id.buy1);
        logout = findViewById(R.id.logout);
        menu =findViewById(R.id.menu);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    builder = new AlertDialog.Builder(HomeScreenActivity.this, android.R.style.Theme_Material_Light_Dialog_Alert);
                } else {
                    builder = new AlertDialog.Builder(HomeScreenActivity.this);
                }
                builder.setTitle(getResources().getString(R.string.app_name))
                        .setMessage("Are you sure you want to logout in the app")
                        .setPositiveButton(Html.fromHtml("<font color='#008037'>Ok</font>"), new DialogInterface.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                            public void onClick(final DialogInterface dialog, int which) {
                                SharedHelper.putKey(HomeScreenActivity.this, APPCONSTANT.USERID);
                                Intent intent = new Intent(HomeScreenActivity.this, SelectTypeActivity.class);
                                if(Build.VERSION.SDK_INT >= 11) {
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                } else {
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                }
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton(Html.fromHtml("<font color='#008037'>Cancel</font>"), new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .setIcon(R.drawable.ic_twotone_power_settings_new_24)
                        .show();
            }
        });


        mail_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreenActivity.this,ContectUsActivity.class);
                startActivity(intent);
            }
        });

        sell_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreenActivity .this,SellItemActivity.class);
                startActivity(intent);
            }
        });

        buyitems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreenActivity .this,BuyItemActivity.class);
                startActivity(intent);
            }
        });

    }
}