package com.devrik.gaonbazaarsplash;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.devrik.gaonbazaarsplash.Model.CategoryModel;
import com.devrik.gaonbazaarsplash.others.API;
import com.devrik.gaonbazaarsplash.others.Show_Category_Adapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class BuyItemActivity extends AppCompatActivity {
    Context context = BuyItemActivity.this;

    RecyclerView.LayoutManager layoutManager ;
    ArrayList<CategoryModel> categoryModelArrayList ;
    RecyclerView rv_cate;

    ImageView menu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_category_screen);
        menu = findViewById(R.id.menu);
        rv_cate = findViewById(R.id.rv_cate);


        show_Category();

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BuyItemActivity  .this,ConsultancyService.class);
                startActivity(intent);
            }
        });

    }

    public void show_Category() {
        AndroidNetworking.post(API.show_category)
                .setTag("showCategory")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("safdadfa", response.toString());
                        categoryModelArrayList= new ArrayList<>();

                        try {


                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                Log.e("dfzcc",response.toString());
                                CategoryModel catModel = new CategoryModel();


                                catModel.setImage(jsonObject.getString("image"));
                                catModel.setPath(jsonObject.getString("path"));
                                catModel.setName(jsonObject.getString("name"));
                                Log.e("fdgfg", jsonObject.getString("image"));
                                Log.e("fdgfg", jsonObject.getString("path"));
                                Log.e("fdgfg", jsonObject.getString("name"));
                                catModel.setId(jsonObject.getString("id"));
                                categoryModelArrayList.add(catModel);
                            }






                            rv_cate.setHasFixedSize(true);
                            layoutManager = new GridLayoutManager(BuyItemActivity.this,2);
                            rv_cate.setLayoutManager(layoutManager);
                            Show_Category_Adapter adapter = new Show_Category_Adapter(context,categoryModelArrayList);
                            rv_cate.setAdapter(adapter);


                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("dgfffdf", e.getMessage());
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("fhsdds", anError.getMessage());
                    }
                });

    }


}