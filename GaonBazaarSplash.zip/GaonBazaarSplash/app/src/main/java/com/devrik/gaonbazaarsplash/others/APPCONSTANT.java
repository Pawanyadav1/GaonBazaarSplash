package com.devrik.gaonbazaarsplash.others;

public class APPCONSTANT {
    public static String USERID="USERID";
    public static String USERTYPE="USERTYPE";
    public static String MOBILE="MOBILE";
    public static String name="name";
    public static String user_id="user_id";
    public static String id="id";

}
