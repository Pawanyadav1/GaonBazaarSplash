package com.devrik.gaonbazaarsplash.others;

import android.content.Context;
import android.content.SharedPreferences;

import com.devrik.gaonbazaarsplash.ShowMyProductActivity;
import com.devrik.gaonbazaarsplash.SignInGaonActivity;
import com.devrik.gaonbazaarsplash.SplashGaonScreen;

public class SharedHelper {
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;
    private static String MY_PREF = "MY_PREF";
    private static String Value;
    private static String Key;

    public static void putKey(Context context, String USERID) {
        sharedPreferences = context.getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.putString(Key, Value);
        editor.commit();
    }

    public static String getKey(Context context, String Key) {

        sharedPreferences = context.getSharedPreferences(MY_PREF, Context.MODE_PRIVATE);
        return sharedPreferences.getString(Key, "");

    }

    public static void putKey(ShowMyProductActivity showMyProductActivity, String userid) {
    }

    public static String getKey(SplashGaonScreen splashGaonScreen, String userid) {
        return userid;
    }

    public static void putKey(SignInGaonActivity signInGaonActivity, String userid, String id) {
    }
}
