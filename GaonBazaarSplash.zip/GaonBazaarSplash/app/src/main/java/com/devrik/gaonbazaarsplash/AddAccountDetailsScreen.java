package com.devrik.gaonbazaarsplash;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.gaonbazaarsplash.others.API;
import com.devrik.gaonbazaarsplash.others.APPCONSTANT;
import com.devrik.gaonbazaarsplash.others.SharedHelper;
import com.google.android.material.button.MaterialButton;

import org.json.JSONException;
import org.json.JSONObject;

public class AddAccountDetailsScreen extends AppCompatActivity {
    EditText ac_name,account_no,bankname,branch,ifsc;
    MaterialButton button1;
    String USERID="",user_id="";
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_account_details_screen);

        user_id= SharedHelper.getKey(AddAccountDetailsScreen.this, APPCONSTANT.user_id);
       Log.e("select", user_id+"");

        back = findViewById(R.id.back);
        ac_name = findViewById(R.id.ac_name);
        account_no = findViewById(R.id.account_no);
        bankname = findViewById(R.id.bankname);
        branch = findViewById(R.id.branch);
        ifsc = findViewById(R.id.ifsc);
        button1 = findViewById(R.id.button1);

        USERID= SharedHelper.getKey(AddAccountDetailsScreen.this, APPCONSTANT.USERID);
        Log.e("select", USERID+"");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(AddAccountDetailsScreen.this,TotalAmountActivity.class));

            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Validation();

            }
        });
    }

    private void Validation(){

        if (ac_name.getText().toString().trim().equals("")) {
            ac_name.setError("please enter A/C Holder Name");
            ac_name.requestFocus();

        } else if (account_no.getText().toString().trim().equals("")) {
            account_no.setError("enter your Account Number");
            account_no.requestFocus();

        } else if (bankname.getText().toString().trim().equals("")) {
            bankname.setError("please enter Bank Name");
            bankname.requestFocus();

        } else if (branch.getText().toString().trim().equals("")) {
            branch.setError("please enter Branch Name ");
            branch.requestFocus();
        } else if (ifsc.getText().toString().trim().equals("")) {
            ifsc.setError("please enter IFSC Code");
            ifsc.requestFocus();
        }else {

            add_bank_account();

        }

    }

private void add_bank_account() {
    AndroidNetworking.post(API.add_bank_account)

            .addBodyParameter("account_holder",ac_name.getText().toString().trim())
            .addBodyParameter("user_id",USERID)
            .addBodyParameter("account_number",account_no.getText().toString().trim())
            .addBodyParameter("bank_name",bankname.getText().toString().trim())
            .addBodyParameter("branch",branch.getText().toString().trim())
            .addBodyParameter("ifsc_code",ifsc.getText().toString().trim())
            .setTag("add_bank_account")
            .setPriority(Priority.MEDIUM)
            .build()
            .getAsJSONObject(new JSONObjectRequestListener() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.e("show_error", response.toString() );
                    try {
                        if (response.getString("result").equals("successful")) {

                            startActivity(new Intent(AddAccountDetailsScreen.this,AvailableBalanceActivity.class));
                           // user_id= SharedHelper.putKey(AddAccountDetailsScreen.this, APPCONSTANT.user_id);
                            SharedHelper.putKey(AddAccountDetailsScreen.this, APPCONSTANT.USERID);
                        }else {


                            Toast.makeText(AddAccountDetailsScreen.this, ""+response.getString("result"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("unsuccessfdd", e.getMessage());

                    }
                }

                @Override
                public void onError(ANError anError) {
                    Log.e("unsuccesssd", anError.getMessage());

                }


            });

}
}
