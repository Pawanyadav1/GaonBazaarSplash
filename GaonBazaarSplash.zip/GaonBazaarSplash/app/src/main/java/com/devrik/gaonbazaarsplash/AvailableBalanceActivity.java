package com.devrik.gaonbazaarsplash;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AvailableBalanceActivity extends AppCompatActivity {

  TextView histroy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_available_balance);

        histroy = findViewById(R.id.histroy);

        histroy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AvailableBalanceActivity.this,TransactionWeeklyActivity.class));
            }
        });
    }
}