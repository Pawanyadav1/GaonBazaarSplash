package com.devrik.gaonbazaarsplash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.devrik.gaonbazaarsplash.others.APPCONSTANT;
import com.devrik.gaonbazaarsplash.others.SharedHelper;

public class SplashGaonScreen extends AppCompatActivity {

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaon_bazaar_screen);

        String USERID = SharedHelper.getKey(SplashGaonScreen.this, APPCONSTANT.USERID);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {


              if (USERID.equals(""))
              {
                    startActivity(new Intent(SplashGaonScreen.this, SelectTypeActivity.class));

              }else
                  {
                    startActivity(new Intent(SplashGaonScreen.this, HomeScreenActivity.class));

                }
            }}, 2500);


    }
}