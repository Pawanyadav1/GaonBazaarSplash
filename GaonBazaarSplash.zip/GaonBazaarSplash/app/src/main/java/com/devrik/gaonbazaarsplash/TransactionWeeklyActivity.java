package com.devrik.gaonbazaarsplash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TransactionWeeklyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_weekly);
    }
}