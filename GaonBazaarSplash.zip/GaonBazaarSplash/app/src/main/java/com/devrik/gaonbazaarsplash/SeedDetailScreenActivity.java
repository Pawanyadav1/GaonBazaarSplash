package com.devrik.gaonbazaarsplash;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.gaonbazaarsplash.Model.MyModel;
import com.devrik.gaonbazaarsplash.others.API;
import com.devrik.gaonbazaarsplash.others.Show_Product_Adapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SeedDetailScreenActivity extends AppCompatActivity {
    Context context = SeedDetailScreenActivity.this;

    RecyclerView.LayoutManager layoutManager ;
    ArrayList<MyModel> myModelArrayList = new ArrayList<>();
    RecyclerView rvProduct;
    String value;
    String USERID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seed_detail_screen);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            value = extras.getString("CAT_ID");
            //The key argument here must match that used in the other activity
        }

        rvProduct = findViewById(R.id.rvProduct);


                show_product();


    }

    public void show_product() {
        AndroidNetworking.post(API.show_product)
                .addBodyParameter("user_id",USERID)
                .setTag("product")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("dsafdadfa", response.toString());
                        try {
                            JSONArray jsonArray = new JSONArray(response.getString("data"));
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                Log.e("dfzcc",response.toString());

                                MyModel mymodel = new MyModel();
                                mymodel.setCommdity(jsonObject.getString("commdity"));
                                mymodel.setVariety(jsonObject.getString("variety"));
                                mymodel.setBrandName(jsonObject.getString("BrandName"));
                                mymodel.setBrand(jsonObject.getString("brand"));
                                mymodel.setCompany(jsonObject.getString("company"));
                                mymodel.setImage(jsonObject.getString("image"));
                                mymodel.setPath(jsonObject.getString("path"));
                                mymodel.setPrice(jsonObject.getString("price"));
                                mymodel.setQuantity(jsonObject.getString("quantity"));
                                mymodel.setStock(jsonObject.getString("stock"));
                                mymodel.setName(jsonObject.getString("name"));
                                mymodel.setId(jsonObject.getString("id"));

                                myModelArrayList.add(mymodel);


                                rvProduct.setHasFixedSize(true);
                                layoutManager = new LinearLayoutManager(SeedDetailScreenActivity.this, RecyclerView.VERTICAL, false);
                                rvProduct.setLayoutManager(layoutManager);
                                Show_Product_Adapter adapter = new Show_Product_Adapter(context, myModelArrayList);
                                rvProduct.setAdapter(adapter);



                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("dgfffdf", e.getMessage());
                        }

                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.e("fhsdds", anError.getMessage());

                    }
                });

    }
}