package com.devrik.gaonbazaarsplash;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.devrik.gaonbazaarsplash.Model.MyModel;
import com.devrik.gaonbazaarsplash.others.API;
import com.devrik.gaonbazaarsplash.others.APPCONSTANT;
import com.devrik.gaonbazaarsplash.others.SharedHelper;
import com.devrik.gaonbazaarsplash.others.ShowMyProductAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ShowMyProductActivity extends AppCompatActivity {

    Context context = ShowMyProductActivity.this;

    RecyclerView.LayoutManager layoutManager;
    ArrayList<MyModel> myModelArrayList = new ArrayList<>();
    RecyclerView rv_myProduct;
    String value;
    String User_ID="";
    String ID="";
    public JSONArray jsonArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_my_product);
        rv_myProduct = findViewById(R.id.rv_myProduct);
        User_ID = SharedHelper.getKey(ShowMyProductActivity.this, APPCONSTANT.user_id);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            value = extras.getString("CAT_ID");
            //The key argument here must match that used in the other activity
        }

        Log.e("select", User_ID+"");


        show_product();


    }
    public void show_product()
    {
        Log.e("fdsfds", User_ID+"");
        AndroidNetworking.post(API.show_my_product)
                .addBodyParameter("id",ID)
                .addBodyParameter("user_id", User_ID)
                .addBodyParameter("category_id",value)
                .setTag("product")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("fafdddfa", response.toString());
                        try {
                            for(int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                JSONObject result = jsonObject.getJSONObject("TAG_JSON_ARRAY");
                               JSONArray tags = jsonObject.getJSONArray("KEY_USER_TAGS");
                                Log.e("dfzcc", response.toString());

                                MyModel mymodel = new MyModel();
                                mymodel.setCommdity(jsonObject.getString("commdity"));
                                mymodel.setVariety(jsonObject.getString("variety"));
                                mymodel.setBrand(jsonObject.getString("Brand"));
                                mymodel.setCompany(jsonObject.getString("company"));
                                mymodel.setImage(jsonObject.getString("image"));
                                mymodel.setName(jsonObject.getString("name"));
                                mymodel.setPath(jsonObject.getString("Path"));
                                mymodel.setBrandName(jsonObject.getString("BrandName"));
                                mymodel.setPrice(jsonObject.getString("price"));
                                mymodel.setCategoryName(jsonObject.getString("categoryname"));
                                mymodel.setQuantity(jsonObject.getString("quantity"));
                                mymodel.setStock(jsonObject.getString("stock"));
                                myModelArrayList.add(mymodel);

                                rv_myProduct.setHasFixedSize(true);
                                layoutManager = new LinearLayoutManager(ShowMyProductActivity.this, RecyclerView.VERTICAL, false);
                                rv_myProduct.setLayoutManager(layoutManager);
                                ShowMyProductAdapter adapter = new ShowMyProductAdapter(context, myModelArrayList);
                                rv_myProduct.setAdapter(adapter);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("dgfffdf", e.getMessage());
                        }
                    }
                    @Override
                    public void onError(ANError anError) {
                        Log.e("fhsdds", anError.getMessage());
                    }
                });
    }
}

