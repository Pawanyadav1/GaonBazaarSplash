package com.devrik.gaonbazaarsplash.others;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.devrik.gaonbazaarsplash.Model.MyModel;
import com.devrik.gaonbazaarsplash.R;
import com.devrik.gaonbazaarsplash.TotalAmountActivity;

import java.util.ArrayList;


public class Show_Product_Adapter extends RecyclerView.Adapter<Show_Product_Adapter.ViewHolder> {
        Context context;
        ArrayList<MyModel> myModelArrayList;

        public Show_Product_Adapter(Context context, ArrayList<MyModel> myModelArrayList) {
            this.context = context;
            this.myModelArrayList = myModelArrayList;
        }

        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.product_list,parent,false);
            ViewHolder viewHolder=new ViewHolder(view);


            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            MyModel  myModel = myModelArrayList.get(position);

            if (!myModel.equals("")) {
                //    holder.allCategoriesBinding.tvPrice.setText(modelCategory.getPrice());
                holder.txtCommdity.setText(myModel.getCommdity());
                holder.txtvariety.setText(myModel.getVariety());
                holder.txtbrand.setText(myModel.getBrandName());
                holder.txtcompeny.setText(myModel.getCompany());
                holder.name.setText(myModel.getName());
                holder.txtprice.setText(myModel.getPrice());


                try {
                    Glide.with(context).load(myModel.getPath()+myModel.getImage())
                            .placeholder(R.drawable.seeds).override(50, 50)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(holder.seed_img);

                    holder.btn_addcard.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.i("TAG","RAM"+myModel);

                            Toast.makeText(context,"found id"+ myModel.getId(),Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context, TotalAmountActivity.class);
                            intent.putExtra("PROD_ID",myModel.getId());
                            context.startActivity(intent);
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e("dgfadf", e.getMessage());

                }
            }

        }

        @Override
        public int getItemCount() {
            return myModelArrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{
            ImageView seed_img;
            Button btn_addcard;
            TextView name,txtCommdity,txtvariety,txtbrand,txtprice,txtcompeny;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                seed_img=itemView.findViewById(R.id.seed_img);
                txtCommdity=itemView.findViewById(R.id.txtCommdity);
                txtvariety=itemView.findViewById(R.id.txtvariety);
                btn_addcard=itemView.findViewById(R.id.btn_addcard);
                txtbrand=itemView.findViewById(R.id.txtbrand);
                txtcompeny=itemView.findViewById(R.id.txtcompeny);
                name=itemView.findViewById(R.id.name);
                txtprice=itemView.findViewById(R.id.txtprice);
            }
        }
    }

