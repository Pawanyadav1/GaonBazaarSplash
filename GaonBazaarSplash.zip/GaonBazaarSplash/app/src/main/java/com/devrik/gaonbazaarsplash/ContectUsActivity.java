package com.devrik.gaonbazaarsplash;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.gaonbazaarsplash.others.API;
import com.google.android.material.button.MaterialButton;

import org.json.JSONObject;


public class ContectUsActivity extends AppCompatActivity {
    EditText et_email, et_massage;
    ImageView back_btn,call_btn;
    MaterialButton btn_sand_massage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contect_us);


        btn_sand_massage = findViewById(R.id.btn_sand_massage);
        et_email = findViewById(R.id.et_email);
        et_massage = findViewById(R.id.et_massage);
        back_btn = findViewById(R.id.back_btn);
        call_btn = findViewById(R.id.call_btn);

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContectUsActivity.this, HomeScreenActivity.class);
                startActivity(intent);
            }
        });



        btn_sand_massage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validateDetail();
            }
        });
    }

    private void validateDetail() {
            if (et_email.getText().toString().equals("")) {
                et_email.setError("please enter email ");
                et_email.requestFocus();

            } else if(et_massage.getText().toString().equals("")) {
                et_massage.setError("please enter massage");
                et_massage.requestFocus();
            }
            else {
                contectus();

            }

        }

        private void contectus() {
            AndroidNetworking.post(API.contact_us)
                    .addBodyParameter("email", et_email.getText().toString().trim())
                    .addBodyParameter("message",et_massage.getText().toString().trim())
                    .setTag("contact us")
                    .setPriority(Priority.HIGH)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e("contact", response.toString());

                            String no=et_email.getText().toString();
                            String msg=et_massage.getText().toString();

                            //Getting intent and PendingIntent instance
                            Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                            PendingIntent pi=PendingIntent.getActivity(getApplicationContext(), 0, intent,0);

                            //Get the SmsManager instance and call the sendTextMessage method to send message
                            SmsManager sms=SmsManager.getDefault();
                            sms.sendTextMessage(no, null, msg, pi,null);

                            Toast.makeText(getApplicationContext(), "Message Sent successfully!",
                                    Toast.LENGTH_LONG).show();

                        }
                        @Override
                        public void onError(ANError anError) {

                            Log.e("xSscSssx", anError.getMessage());

                        }
                    });
        }
}
