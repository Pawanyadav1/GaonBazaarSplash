package com.devrik.gaonbazaarsplash;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.devrik.gaonbazaarsplash.others.API;
import com.devrik.gaonbazaarsplash.others.APPCONSTANT;
import com.devrik.gaonbazaarsplash.others.SharedHelper;

import org.json.JSONException;
import org.json.JSONObject;

public class SignInGaonActivity extends AppCompatActivity {
EditText phone;
EditText password;
TextView forget;
Button button2;
TextView text;
String USERTYPE="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_gaon);

        phone = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        forget = findViewById(R.id.forget);
        button2 = findViewById(R.id.button2);
        text = findViewById(R.id.text);


        USERTYPE = getIntent().getStringExtra("userType");


        forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignInGaonActivity.this,ForgetPasswordActivity.class);
                startActivity(intent);
            }
        });
        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignInGaonActivity.this,SignUpGaon.class);
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                validateDetail();

            }


        });
    }


    private void validateDetail() {
        if (phone.getText().toString().equals("")) {
            phone.setError("please enter Mobile Number");
            phone.requestFocus();

        } else if (password.getText().toString().equals("")) {
            password.setError("please enter your password");
            password.requestFocus();
        } else {

            signinGoan();

        }
    }

    private void signinGoan(){
        Log.e("type",USERTYPE);
        Log.e("mobile",phone.getText().toString().trim());
        Log.e("password", password.getText().toString().trim());
        AndroidNetworking.post(API.login)
                .addBodyParameter("type", USERTYPE)
                .addBodyParameter("phone",phone.getText().toString().trim())
                .addBodyParameter("password",password.getText().toString().trim())
                .setTag("signin")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("API RESPONSE : ", response.toString() );
                        try {
                            if (response.getString("result").equals("login sucessfully")) {

                                SharedHelper.putKey(SignInGaonActivity.this, APPCONSTANT.USERID,response.getString("id"));
                                SharedHelper.putKey(SignInGaonActivity.this, APPCONSTANT.MOBILE, APPCONSTANT.MOBILE);

                                startActivity(new Intent(SignInGaonActivity.this,UpDateProfileActivity.class));

                                }
                            else {

                                Toast.makeText(SignInGaonActivity.this, "LogIn successfully"+response.getString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.e("success", e.getMessage());
                        }
                    }




                    @Override
                    public void onError(ANError anError) {

                        Log.e("dffgdfg", anError.getMessage());
                    }
                });

    }
}
