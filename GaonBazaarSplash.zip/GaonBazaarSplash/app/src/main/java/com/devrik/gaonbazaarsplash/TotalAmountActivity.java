package com.devrik.gaonbazaarsplash;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class TotalAmountActivity extends AppCompatActivity {
ImageView back_btn;
    Button btn_next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_amount);
        back_btn = findViewById(R.id.back_btn);
        btn_next = findViewById(R.id.btn_next);

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TotalAmountActivity.this,SeedDetailScreenActivity.class));
            }
        });
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(TotalAmountActivity.this,AddAccountDetailsScreen.class));

            }
        });
    }
}