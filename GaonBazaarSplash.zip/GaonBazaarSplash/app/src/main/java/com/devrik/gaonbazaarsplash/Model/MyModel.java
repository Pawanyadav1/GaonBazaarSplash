package com.devrik.gaonbazaarsplash.Model;

public class MyModel {

      String id="";
    String category_id="";
    String brand="";
    String name="";
    String image="";
    String path="";
    String commdity="";
    String variety="";
    String company="";
    String price="";
    String quantity="";
    String stock="";
    String BrandName="";
    String categoryName="";
    String categoryImage="";

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getStock() {
        return stock;
    }

    public String getCategoryImage() {
        return categoryImage;
    }

    public void setCategoryImage(String categoryImage) {
        this.categoryImage = categoryImage;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getCommdity() {
        return commdity;
    }

    public void setCommdity(String commdity) {
        this.commdity = commdity;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getCompany() {

        return company;
    }

    public void setCompany(String company) {

        this.company = company;
    }

    public String getQuantity(String quantity) {

        return this.quantity;
    }

    public void setQuantity(String quantity) {

        this.quantity = quantity;
    }

    public String getStock(String stock) {
        return this.stock;
    }

    public void setStock(String stock) {

        this.stock = stock;
    }

    public String getBrandName() {

        return BrandName;
    }

    public void setBrandName(String brandName) {

        BrandName = brandName;
    }

    public String getCategoryName() {

        return categoryName;
    }

    public void setCategoryName(String categoryName) {

        this.categoryName = categoryName;
    }
}