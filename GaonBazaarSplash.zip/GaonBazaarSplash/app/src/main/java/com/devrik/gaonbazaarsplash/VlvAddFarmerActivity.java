package com.devrik.gaonbazaarsplash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VlvAddFarmerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vlv_add_farmer);
    }
}